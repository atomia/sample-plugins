﻿Testing command line provisioning plugin

1. Prerequisites:
	- Installed Atomia Automation Server on local machine in bootstrap mode
	- Installed Microsoft .NET Framework 4.0
	- Installed Atomia Command Line tool or Installed AutomationServerClient, as testing tool.

	This comes with Atomia Automation Server installation but should be checked: 
	- Installing provisioning module for supporting command line plugins
		- Be shure that in Program Files (x86)/Atomia/AutomationServer/Common/Modules, exist file Atomia.Provisioning.Modules.CmdLocal.dll
		- Be shure that in Program Files (x86)/Atomia/AutomationServer/Common/Resources.xml file, there is resource description for CmdLocal module
		- Next two dlls should be in Program Files (x86)/Atomia/AutomationServer/Common/Modules folder: Atomia.Provisioning.Base.dll, Atomia.Provisioning.Base.Module.dll

2. Prepare your plugin project
	- .NET
		Prerequisites:
			- Visual Studio 2010
			- .NET Framework 4.0
		
		Download AtomiaAutomationServer SDK.zip, unpack it and copy 'Automation Server Console Line Plugin Project Template' folder to your working folder.
		Template must be changed a little, we will set project name, and namespaces so that your project gets its identity.
			- Open solution Atomia.Provisioning.Modules.Folders.sln in visual studio, and open project properties. Set AssemblyName, Default NameSpace, open AssemblyInformation and set Title and Product. All this can have the same value, for example Atomia.Provisioning.Modules.<MyPlugin>. It is recomendable that you change project GUID with valid guid.
			- Rename file TemplateCommand.cs to <MyPlugin>Command.cs, open file and rename namespace and constructor in same way.
			- Rename Template.cs to <MyPlugin>.cs, open file and rename namespace, using, class name and constructor in same way. Also rename TemplateCommand to <MyPlugin>Command in code
			- Open file program.cs and rename Template to <MyPlugin> in namespace and in code.
			- Right click on project and rename from Template to <MyPlugin>

			
3. Programming provisioning plugin
	- Write <MyPlugin>Command
	- Change ServiceDescription.xml
	- Change ResourceDescription.xml
	- Build and install plugin
	
	These tasks are explained in "Provisioning Folders Example", so it is recomended to continue work by examining example.
	
4. Appendix: Instructions for working with CmdLocal commands
	Purpose of CmdLocal commands is to define how data are parssed by CmdLocal module in order to form command for console or command line application which provide service.
	Currently we have supported next commands:
		- Add service 'AddExecuteCmd', 'AddCommitCmd, 'AddRollbackCmd'
		- Modify service 'ModExecuteCmd', 'ModCommitCmd, 'ModRollbackCmd'
		- Remove service 'RemExecuteCmd', 'RemCommitCmd, 'RemRollbackCmd'
		- Calls Operation 'OperationMapping'
	
	For provisioning services we can write console plugin application for provisioning services, which use 'universal' CmdLocal module(which is tool to pass commands from Atomia Automation Server to console line application), 
	or we can define commands which will be executed directly sending commands to console(without console plugin application).

	Here we will explain how to write service description and define commands for both cases.
	
	4.1. Service which use console plugin application for provisioning services(through CmdLocal module)
		First lets look at simple example for service description for service which manage files(create, rename, delete):
			<simpleService name="Files" friendlyName="Files">
				<propertyList>
					<property name="Id" friendlyName="Id" defaultValue="123"/>
					<property name="Name" friendlyName="Name" defaultValue="TestFile.txt" key="true"/>
					<property name="ParentFolder" friendlyName="Parent folder" key="true" defaultValue="WillTakeValueFromParentService"/>
					<property name="Content" friendlyName="File content" defaultValue="123"/>					
					<property name="StdinStdout" friendlyName="Is command going to accept and return JSON encoded service via stdin/stdout" defaultValue="false" required="true" />
					<property name="UseCmdLinePlugin" friendlyName="Are commands going to use plugin command line app for provisioning" defaultValue="true" required="true" />
					<property name="AddExecuteCmd" friendlyName="Command to be executed to add File, begin transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Add --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="AddCommitCmd"  friendlyName="Command to be executed to add File, commit transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Add --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="AddRollbackCmd" friendlyName="Command to be executed to add File, rollback transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Add --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="RemoveExecuteCmd" friendlyName="Command to be executed to remove File, begin transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Remove --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="RemoveCommitCmd" friendlyName="Command to be executed to remove File, commit transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Remove --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="RemoveRollbackCmd" friendlyName="Command to be executed to remove File, rollback transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Remove --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="ModifyExecuteCmd" friendlyName="Command to be executed to modify File, begin transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Modify --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="ModifyCommitCmd" friendlyName="Command to be executed to modify File, commit transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Modify --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="ModifyRollbackCmd" friendlyName="Command to be executed to modify File, rollback transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Modify --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
					<property name="OperationMappingCmd" friendlyName="Define how opperations are executed" defaultValue="GetFullFilePath:Atomia.Provisioning.Modules.Folders.exe --CallOp --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[ParentFolder]}" required="true" />
				</propertyList>
				<operationList>
					<operation name="GetFullFilePath" />
				</operationList>
			</simpleService>
			
			In this service definition we have properties which can be grouped by their purpose:
				a) regular properties - which holds real service properties (Id, Name, ParentFolder, Content)
				b) command usability properties - which are parameters for how commands from next group are parsed(StdinStdout, UseCmdLinePlugin)
				c) command properties - which describes/defines how service will be provided(AddExecuteCmd, ... , ModifyRollbackCmd, OperationMappingCmd)
				
			a) These properties can be defined freely and depends of service nature and logic. They are defined by programmers and will be diferent from service to service.
			b) These properties are required and only can be changed their defaultValue to true or false
				- StdInStdOut - used only when we have console plugin application. If true then whole service(together with parent services) will be json serialized and send as argument to console plugin application. 
					Console plugin application will deserialize service data, will provide service, maybe change some service property, and also will return back whole json serialized service which will have eventualy changed properties.
					In CmdLocal module, service data will be deserialized and service will be updated with changed values. We can see that this is used when provisioning console application plugin change some services, and we want that 
					service data is updated with changes.
				- UseCmdLinePlugin - marks if commands in c) group are formed to use provisioning console plugin application or will be executed directly to console. In first case we will set defaultValue for this property to 'true', otherwise to 'false'.
			c) These properties are required and must exists. How commands are executed is defined in defaultValue, and if in some cases default value is empty, then required must be set to false. 
				We can see that we have sets of three properties(execute, commit, and rollback) for adding, modifying and removing service, and one for executing service operations. We need three commands for every action, because we must change service(add, modify or remove) in atomic maner, and we must execute it in transaction. 
				Keep in mind that we can have complex services for which provisioning a number of smiple services will be called for provisioning, and that must be in transaction.
				Automation server himself for every service manipulation calls plugin at least three times, first to begin transaction, then to execute command, and if everything is OK commit transaction is called, or rollback if some error occured.  So we must to define what will happen with service when executing starts(execute or begin transaction), when executing is finished well(commit transaction) and if something gone wrong we must define how executing will be returned to previous state(rollback transaction). 				
				To have better picture of what we are talking about, lets see our example which provision files, and analyze case when we want to rename existing file(service). In order to support transaction in Execute(begin transaction) we will make copy of file with name filename_ReserveForRollback, and will rename file to new value.
				In Commit part we will left renamed file, and will delete copy filename_ReserveForRollback. In rollback, we need to revert state to previous, we will delete renamed file, and will rename filename_ReserveForRollback to filename, so we will have state like before modify service command is started.
				Of course this can be done in different way, idea here is to explain principles for what we use execute, comit and rollback commands. 
				
				Now we can explain structure of one command. We will take ModifyExecuteCmd for example:
				
				<property name="ModifyExecuteCmd" friendlyName="Command to be executed to modify File, begin transaction" defaultValue="Atomia.Provisioning.Modules.Folders.exe --Modify --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}" required="true" />
				
				friendlyName can be change freely to adequatly describe command, but main part of command is defaultValue which is made from next parts:
					- 'Atomia.Provisioning.Modules.Folders.exe' - first part is name of console plugin application, which must exist in Common\Modules\ subfolder of Automation Server instalation folder.
					- '--Modify' - second part is command code and can have one of supported values: Add, Remove, Modify, CallOp.
					- '--RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[parent.Name]} --Content {service[Content]}' - third part is list of resource and service properties which will be used during provisioning service. 
						CmdLocal don't know values for properties until some concrete instance is managed, and we don't wan't to send all service properties to console line plugin application, only properties of resource and service listed in command definition will be send to console plugin application.
						If we want to use some service property, we will write something like this: '--Content {service[Content]}', where 'Content' is existing property of service. For resource we will have something like '--RootFolder {resource[RootFolder]}', where 'RootFolder' is property of resource.
						As addition we can use some property of parent service and we will write: '--ParentFolder {service[parent.Name]}' or instead of parent.Name we can write parent.parent.parent.Name, only we must be sure that such parent exist, otherwise error will be thrown during executing service request.
						
				For OperationMappingCmd we have a something difference syntax, because we can have more than one operation, and all should be defined in this one property. So in defaultValue we will have next syntax:
					Op1Name:Op1Def, Op2Name, Op2Def, where for OpxDef we have same rules as for defining other commands. Here is example:
					<property name="OperationMappingCmd" friendlyName="Define how opperations are executed" defaultValue="GetFullFilePath:Atomia.Provisioning.Modules.Folders.exe --CallOp --RootFolder {resource[RootFolder]} --Name {service[Name]} --ParentFolder {service[ParentFolder]}" required="true" />
					For operation GetFullFilePath we have definition which contains name of console line application, Command code, and list of resource and service properties which are used in operation.
						
	
	4.2. Service which have defined commands which will be executed directly sending commands to console(without console plugin application)
		First lets look at simple example for service description for service which manage files(create, rename, delete), but now without console line application, commands will be directly sent to console:
			<simpleService name="FilesWithoutPlugin" friendlyName="Files service, where files are provisioned without command line plugin application. Direct command line commands are used.">					
				<propertyList>
					<property name="Id" friendlyName="Id" defaultValue="123"/>
					<property name="Name" friendlyName="Name" defaultValue="TestFile.txt" key="true"/>
					<property name="ParentFolder" friendlyName="Parent folder" key="true" defaultValue="WillTakeValueFromParentService"/>
					<property name="Content" friendlyName="File content" defaultValue="123"/>                            
					<property name="StdinStdout" friendlyName="Is command going to accept and return JSON encoded service via stdin/stdout" defaultValue="false" required="true" />
					<property name="UseCmdLinePlugin" friendlyName="Are commands going to use plugin command line app for provisioning" defaultValue="false" required="true" />                            
					<property name="AddExecuteCmd" friendlyName="Command to be executed to add File, begin transaction" defaultValue="echo {service[Content]} > {resource[RootFolder]}{service[parent.Name]}\{service[Name]}" required="true" />
					<property name="AddCommitCmd"  friendlyName="Command to be executed to add File, commit transaction" defaultValue="" required="false" />
					<property name="AddRollbackCmd" friendlyName="Command to be executed to add File, rollback transaction" defaultValue="del {resource[RootFolder]}{service[parent.Name]}\{service[Name]}" required="true" />
					<property name="RemoveExecuteCmd" friendlyName="Command to be executed to remove File, begin transaction" defaultValue="ren {resource[RootFolder]}{service[parent.Name]}\{service[Name]} {service[Name]}_MarkedForDelete" required="true" />
					<property name="RemoveCommitCmd" friendlyName="Command to be executed to remove File, commit transaction" defaultValue="del {resource[RootFolder]}{service[parent.Name]}\{service[Name]}_MarkedForDelete" required="true" />
					<property name="RemoveRollbackCmd" friendlyName="Command to be executed to remove File, rollback transaction" defaultValue="ren {resource[RootFolder]}{service[parent.Name]}\{service[Name]}_MarkedForDelete {service[Name]}" required="true" />
					<property name="ModifyExecuteCmd" friendlyName="Command to be executed to modify File, begin transaction" defaultValue="ren {resource[RootFolder]}{oldservice[parent.Name]}\{oldservice[Name]} {newservice[Name]}" required="true" />
					<property name="ModifyCommitCmd" friendlyName="Command to be executed to modify File, commit transaction" defaultValue="" required="false" />
					<property name="ModifyRollbackCmd" friendlyName="Command to be executed to modify File, rollback transaction" defaultValue="ren {resource[RootFolder]}{newservice[parent.Name]}\{newservice[Name]} {oldservice[Name]}" required="true" />
					<property name="OperationMappingCmd" friendlyName="Define how opperations are executed" defaultValue="GetFullFilePath:echo {resource[RootFolder]}{service[parent.Name]}\{service[Name]}" required="true" />
				</propertyList>
				<operationList>
					<operation name="GetFullFilePath" />
				</operationList>	
			</simpleService>
			
			General explanations for types and purpose of properties can be found in previous chapter 4.1. Here we will explain specific moment for current example.
			
			Lets look same command like in previous example ModifyExecuteCmd. In defaultValue we have next:
				"ren {resource[RootFolder]}{oldservice[parent.Name]}\{oldservice[Name]} {newservice[Name]}"
			We can se that we don't have name of console line application, because now we send command directly to console.
			In ModifyExecuteCmd we want to rename file to new value, and we write down ren command with parts which will be taken from service/resource instance, like RootFolder, parent.Name and Name are. 
			As special case in ModifyCommitCmd we have nothing to do, so defaultValue will left empty, only required is changed to false. This is because Automation Server will throw error if we have required property without value.
			In ModifyRollbackCmd we want to rename file back to original value, so we define oposite ren command then in ModifyExecuteCmd. 
			
			The same principles are applied for other commands in this example. We see that for some cases when it is possible we may provide service without writing Console line plugin module for provisioning such service.
		
		