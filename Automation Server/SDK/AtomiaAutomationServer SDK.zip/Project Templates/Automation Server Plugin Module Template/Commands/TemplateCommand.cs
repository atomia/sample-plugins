﻿//-----------------------------------------------------------------------
// <copyright file="InstanceCommand.cs" company="Atomia AB">
//     Copyright (c) Atomia AB. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using Atomia.Provisioning.Base;
using Atomia.Provisioning.Base.Exceptions;
using Atomia.Provisioning.Base.Module;
using Atomia.Provisioning.Modules.Common;

namespace Atomia.Provisioning.Modules.Template.Commands
{
    /// <summary>
    /// Command which handles Template instances.
    /// </summary>
    public class TemplateCommand : ModuleCommandSimpleBase
    {

		/// <summary>
        /// Service to be added on resource.
        /// </summary>
        protected ModuleService service;

        /// <summary>
        /// Resource that hosts service.
        /// </summary>
        protected ResourceDescription resource;

        /// <summary>
        /// Status of the command.
        /// </summary>
        protected ModuleCommandStatus status = ModuleCommandStatus.NotExecuted;
        public ModuleCommandStatus Status
        {
            get
            {
                return status;
            } 
        }

        /// <summary>
        /// Service settings to be applied.
        /// </summary>
        private ModuleService newServiceSettings;

        /// <summary>
        /// The type of command.
        /// </summary>
        protected ModuleCommandType commandType;

        /// <summary>
        /// The list depth if this is a List command.
        /// </summary>
        protected int listDepth;
		
        /// <summary>
        /// Initializes a new instance of the <see cref="InstanceCommand"/> class.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="resource">The resource.</param>
        /// <param name="newServiceSettings">The new service settings.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="listDepth">The list depth.</param>
        public TemplateCommand(ModuleService service, ResourceDescription resource, ModuleService newServiceSettings, ModuleCommandType commandType, int listDepth)
            : base(service, resource, newServiceSettings, commandType, listDepth)
        {
			this.resource = resource;
            this.service = service;
            this.newServiceSettings = newServiceSettings;
            this.commandType = commandType;
            this.listDepth = listDepth;
        }

		/// <summary>
        /// Executes this  command.
        /// </summary>
        public void Execute(CommandTrancasctionContext transContext)
        {
            try
            {
                switch (this.commandType)
                {
                    case ModuleCommandType.Add:
                        this.ExecuteAdd(this.service, transContext);
                        break;
                    case ModuleCommandType.Modify:
                        this.ExecuteModify(this.service, this.newServiceSettings, transContext);
                        break;
                    case ModuleCommandType.Remove:
                        this.ExecuteRemove(this.service, transContext);
                        break;
                    case ModuleCommandType.List:
                        this.ExecuteList(this.service, this.listDepth, transContext);
                        break;
                    default:
                        throw ExceptionHelper.GetModuleException("ID400019", null, null);
                }

                this.status = ModuleCommandStatus.Executed;
            }
            catch (Exception e)
            {
                this.HandleException(e);
            }
        }
		
		/// <summary>
        /// Undoes this command.
        /// </summary>
        public override void Undo()
        {
            try
            {
                switch (this.commandType)
                {
                    case ModuleCommandType.Add:
                        this.ExecuteRemove(this.service);
                        break;
                    case ModuleCommandType.Modify:
                        this.ExecuteModify(this.newServiceSettings, this.service);
                        break;
                    case ModuleCommandType.Remove:
                        this.ExecuteAdd(this.service);
                        break;
                    default:
                        throw ExceptionHelper.GetModuleException("ID400019", null, null);
                }
            }
            catch (Exception e)
            {
                this.HandleException(e);
            }
        }
		
        /// <summary>
        /// Executes the remove.
        /// </summary>
        /// <param name="moduleService">The module service.</param>
        protected override void ExecuteRemove(ModuleService moduleService)
        {
        }

        /// <summary>
        /// Executes the modify.
        /// </summary>
        /// <param name="oldService">The old service.</param>
        /// <param name="newService">The new service.</param>
        protected override void ExecuteModify(ModuleService oldService, ModuleService newService)
        {
        }

        /// <summary>
        /// Executes the add.
        /// </summary>
        /// <param name="moduleService">The module service.</param>
        protected override void ExecuteAdd(ModuleService moduleService)
        {
        }

        /// <summary>
        /// Validates the service.
        /// </summary>
        /// <param name="moduleService">The module service.</param>
        protected override void ValidateService(ModuleService moduleService)
        {
        }

        /// <summary>
        /// Calls the operation.
        /// </summary>
        /// <param name="operationName">Name of the operation.</param>
        /// <param name="operationArgument">The operation argument.</param>
        /// <returns></returns>
        public override string CallOperation(string operationName, string operationArgument)
        {
            string result = string.Empty;

            switch (operationName)
            {
                case "xyz":
                    {
                    }
                    break;
                default:
                    throw ExceptionHelper.GetModuleException("ID400019", null, null);
            }

            return result;

        }
    }
}