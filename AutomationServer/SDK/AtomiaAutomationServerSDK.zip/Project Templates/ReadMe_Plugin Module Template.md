﻿Using project template for Automation Server Provisioning Plugin

Purpose of project template is to give start point for develop Automation Server Provisioning plugin. Template specific readme file will give instruction for using template, for developing plugin and how to test it.

This concrete project template you should use if you plan to develop plugin in .NET, as standard Automation server plugin. 

Here you can find 
	- instruction how to start developing plugin, 
	- needed prerequisites
	- how to change and adapt this project template so that you can write your own plugin
	- high level explanation how automation server communicate with plugin, and where you will write your code. 
	- how to install new plugin module
	- directions how to test your provisioning plugin module 

1. How to start?

	- Install prerequisites
	- Copy 'Automation Server Plugin Module Template' folder to your working folder.
	- Change and adapt project template so that you can write your plugin
	- Write code for provisioning service, write service and resource description, and insert it into ProvisioningDescription.xml and Resources.xml files
	- Install plugin on test environment and test it
	
2. Prerequisites:

	- Installed Atomia Automation server testing environment on local machine. It contains lite version of Atomia Automation Server, and as testing tools Atomia Command Line tool and Installed AutomationServerClient. Installation can be found in 'AtomiaAutomationServer SDK.zip'.
	- Installed Microsoft .NET Framework 4.0 - you can download it from http://msdn.microsoft.com/en-us/netframework/aa569263	
	- Automation Server Plugin Module Template - can be found in 'AtomiaAutomationServer SDK.zip'.
	- We will develop plugin in .NET so we need MS Visual Studio 2010 installed
		
3. Copy and adapt project template
	
	- Copy 'Automation Server Plugin Module Template' folder to your working folder.
	- We will set project name, change small parts of code and namespaces so that your project gets its identity.
	
		- Open solution Atomia.Provisioning.Modules.Template.sln in visual studio, rename it to Atomia.Provisioning.Modules.<MyPlugin>.
		- Open project properties. Set AssemblyName, Default NameSpace, open AssemblyInformation and set Title and Product. All this can have the same value, for example Atomia.Provisioning.Modules.<MyPlugin>. It is recomendable that you change project GUID with valid guid.
		- Rename project to Atomia.Provisioning.Modules.<MyPlugin>.
		- Rename file TemplateCommand.cs to <MyPlugin>Command.cs, open file and rename namespace, class name and constructor in same way.
		- Rename Template.cs to <MyPlugin>.cs, open file and rename namespace, class name and constructor in same way. Also rename 'Template' word in code to <MyPlugin>.
			
4. Programming provisioning plugin

	4.1. Write <MyPlugin>Command
	4.2. Change ProvisioningDescription.xml
	4.3. Change Resources.xml
	4.4. Build and install plugin
	4.5. Testing plugin	
	
	4.1. Plugin module class in our case is <MyPlugin>.cs, inherits ModuleBase clas, and must implement interface defined in ModuleBase class. In ModuleBase we have defined methods for comunication with Automatin server, and most important are: method for adding service(ProvideService), ModifyService, RemoveService, CallOperation, BeginTransaction, CommitTransaction, RollbackTransaction.
		These methods are called from automation server when some service request is created, and our job is to write code for them. In code pattern we used in template project, there is situation that for our example we don't need to change code in this class. Only if we have more than one command class under Commands folder, then we should add additional case statement in GetModuleCommand method. Support for transactions is already implemented in existing code.
		We will make changes in <MyPlugin>Command.cs class. Our task is to write code for ExecuteAdd, ExecuteRemove, ExecuteModify and CallOperation methods.
		Working example for code you can find in Atomia Automation Server SDK\Examples\ProvisioningModule\Provisioning Folders Plugin Module Example\.
		
	4.2. We need to write service description for our service, and to add it to ProvisioningDescription.xml file. Through service description we define service properties, operations and service behaviour.
		Working example for service description you can find in Atomia Automation Server SDK\Examples\ProvisioningModule\Provisioning Folders Plugin Module Example\Automation Server Plugin Module Folders\ServiceDescription.xml
		Next step is to add our service definition to ProvisioningDescription.xml, find this file in automation server instalation folder(Program Files (x86)/Atomia/AutomationServer)/Common/ProvisioningDescriptions, and find closing tag for </simpleServiceList>. Before it add our service description, save and close file.
		After changing .xml file we should reset iis on machine, so that automation server takes latest changes.
			
	4.3. We need to write resource description for our service, and to add it to Resources.xml file. When some service is provisioned, that is done on some resource. Resource parameters are defined in resource description for service.			
		Working example for service description you can also find in Atomia Automation Server SDK\Examples\ProvisioningModule\Provisioning Folders Plugin Module Example\\Automation Server Plugin Module Folders\ResourceDescription.xml.							
		Next step is to add our resource description to Resources.xml file. Find this file in automation server instalation folder(Program Files (x86)/Atomia/AutomationServer)/Common/, and below tag <resourceDescription> add our resource description, save and close file.
		After changing .xml file we should reset iis on machine, so that automation server takes latest changes.
			
	4.4. Building plugin is easy as building any other project. To install it we only need to copy plugin module dll to automation server instalation folder(Program Files (x86)/Atomia/AutomationServer)/Common/Modules folder. If you have some dependencies you should copy them too to the same folder. ( As dependencies we have two dlls we referenced from our project Atomia.Provisioning.Base.dll and Atomia.Provisioning.Base.Module.dll, so this two items should be copied together with plugin).
			
	4.5. Testing plugin		

		You can test plugin using one of testing tools which are installed together with testing environment.
	
		4.5.1 Testing using atomia command line tool
		
			Open command prompt and position yourself into automation server command line tool instalation folder(Program Files (x86)/Atomia/AutomationServerCmdClient/
			Commands for testing add, modify and remove service should be similar like below:
			
			- Add service:
				
				windows cmdprompt:
					atomia service add --account 100000 --servicedata "{ \"name\" : \"<MyPlugin>\", \"properties\" : { \"<Prop1Name>\" : \"<Prop1Value>\", \"<Prop2Name>\" : \"<Prop2Value>\"}}"
				linux:
					atomia service add --account 100000 --servicedata '{ "name" : "<MyPlugin>", "properties" : { "<Prop1Name>" : "<Prop1Value>", "<Prop2Name>" : "<Prop2Value>"}}'
					
				This command will provide new service. As output from command you will get newly created service data serialized. Find logical id and remember it, because we will need it for change and delete commands.				
			
			- Modify service:
				
				windows cmdprompt:
					atomia service modify --account 100000 --service "67e9a578-7151-4569-93a0-a1c98c165855" --servicedata "{ \"properties\" : { \"Prop1Name\" : \"Prop1Value\"}}"
				linux:
					atomia service modify --account 100000 --service "67e9a578-7151-4569-93a0-a1c98c165855" --servicedata '{ "properties" : { "Prop1Name" : "Prop1Value"}}'
					
				This command will provide change of existing service. serviceId used in this command "67e9a578-7151-4569-93a0-a1c98c165855" is one we get during testing, you must replace it with logicalid you writed down during add command testing.				
				
			- Delete service:
			
				windows cmdprompt:
					atomia service delete --account 100000 --service "67e9a578-7151-4569-93a0-a1c98c165855"
				linux:
					atomia service delete --account 100000 --service "67e9a578-7151-4569-93a0-a1c98c165855"
				
				This command will provide deleting of existing service with given service id. ServiceId used in this command "67e9a578-7151-4569-93a0-a1c98c165855" is one we get during testing, you must replace it with logicalid you writed down during add command testing.

			Difference between windows and linux style commands are in literals and how commands are parsed in OS.
				
		4.5.2 Testing using AutomationServerClient.exe
			Start AutomationServerClient.exe. If you start AutomationServerClient for first time, you should set package which is used for work. From menu open File -> New Package, choose BasePackage and press AddPackage button.
			Also, in ProvisioningDescription.xml find <packageDescription>/<packageList> and find package named BasePackage. Under <serviceList> node, add <service name="<MyPlugin>" />. In this way we set that our service '<MyPlugin>' is part of BasePackage, and later when we want to test it, we will find command for adding new '<MyPlugin>' service when we work with BasePackage.
			
			- Right mouse click on empty area in service list, Add Child Service -> <MyPlugin>, set properties and press OK butoon. New service will appears in list.
			- Next you can try to edit service, right click on it, start Edit Service popup menu command, Edit service form will appear. Change some properties and click OK. After refreshing service tree, we can see that service is changed.
			- At last you can try to delete service, right click on it, start Delete Service popup menu command, prompt will appear, press yes, and service will be deleted. 
		
			
			
		
