﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atomia.Provisioning.Base.Module;
using Atomia.Provisioning.Modules.Common;
using System.Reflection;
using System.IO;
using Atomia.Provisioning.Base;
using Atomia.Provisioning.Modules.Template.Commands;

namespace Atomia.Provisioning.Modules.Template
{
    public class Template : ModuleBase
    {

        /// List of commands in current transaction.
        /// </summary>
        private List<ModuleCommand> commands;

        /// <summary>
        /// Track whether Dispose has been called. 
        /// </summary>
        private bool disposed = false;

        Guid transactionGuid = Guid.Empty;
        string transactionContext = string.Empty;

        /// <summary>
        /// Initializes a new instance of the <see cref="Folders"/> class.
        /// </summary>
        public Template()
        {
            this.commands = new List<ModuleCommand>();
        }

        #region ModuleBase Members

        /// <summary>
        /// Begins the transaction.
        /// </summary>
        public override void BeginTransaction()
        {
            if (this.commands.Count > 0)
            {
                throw ExceptionHelper.GetModuleException("ID400002", null, null);
            }
        }

        /// <summary>
        /// Calls the operation.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="operationName">Name of the operation.</param>
        /// <param name="operationArgument">The operation argument.</param>
        /// <param name="resource">The resource.</param>
        /// <returns>Operation result.</returns>
        public override string CallOperation(ModuleService service, string operationName, string operationArgument, Atomia.Provisioning.Base.ResourceDescription resource)
        {
            ModuleCommand command = this.GetModuleCommand(resource, ModuleCommandType.Add, -1, service);
            if (command is ModuleCommandSimpleBase)
            {
                return ((ModuleCommandSimpleBase)command).CallOperation(operationName, operationArgument);
            }
            else
            {
                throw ExceptionHelper.GetModuleException("ID400018", null, null);
            }
        }

        /// <summary>
        /// Commits the transaction.
        /// </summary>
        public override void CommitTransaction()
        {
            foreach (ModuleCommand command in this.commands)
            {
                command.CleanUp();
            }

            this.commands.Clear();
        }

        /// <summary>
        /// Gets the module service description.
        /// </summary>
        /// <returns>Module service description.</returns>
        public override string GetModuleServiceDescription()
        {
            Assembly assembly = this.GetType().Assembly;
            Stream stream = assembly.GetManifestResourceStream(this.GetServiceDescriptionAssemblyPath());
            StreamReader reader = new StreamReader(stream);
            string description = reader.ReadToEnd();
            return description;
        }

        /// <summary>
        /// Lists the services.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="maxDepth">The max depth.</param>
        /// <param name="resource">The resource.</param>
        /// <returns>List of services.</returns>
        public override ModuleService ListServices(ModuleService service, int maxDepth, Atomia.Provisioning.Base.ResourceDescription resource)
        {
            ModuleCommand command = this.GetModuleCommand(resource, ModuleCommandType.List, maxDepth, service);
            command.Execute();
            return service;
        }

        /// <summary>
        /// Lists the services no children.
        /// </summary>
        /// <param name="serviceName">Name of the service.</param>
        /// <param name="resource">The resource.</param>
        /// <returns>List of services.</returns>
        public override List<ModuleService> ListServicesNoChildren(string serviceName, Atomia.Provisioning.Base.ResourceDescription resource)
        {
            throw ExceptionHelper.GetModuleException("ID400018", null, null);
        }

        /// <summary>
        /// Modifies the service.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="resource">The resource.</param>
        /// <param name="newServiceSettings">The new service settings.</param>
        public override void ModifyService(ModuleService service, Atomia.Provisioning.Base.ResourceDescription resource, ModuleService newServiceSettings)
        {
            this.PrepareCommandList(service, newServiceSettings, resource, ModuleCommandType.Modify);
            this.PrepareAndExecuteCommandsFromList();
        }

        /// <summary>
        /// Moves to resource.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="currentResource">The current resource.</param>
        /// <param name="targetResource">The target resource.</param>
        public override void MoveToResource(ModuleService service, Atomia.Provisioning.Base.ResourceDescription currentResource, Atomia.Provisioning.Base.ResourceDescription targetResource)
        {
            throw ExceptionHelper.GetModuleException("ID400018", null, null);
        }

        /// <summary>
        /// Provides the service.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="resource">The resource.</param>
        public override void ProvideService(ModuleService service, Atomia.Provisioning.Base.ResourceDescription resource)
        {
            this.PrepareCommandList(service, null, resource, ModuleCommandType.Add);
            this.PrepareAndExecuteCommandsFromList();
        }

        /// <summary>
        /// Removes the service.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="resource">The resource.</param>
        public override void RemoveService(ModuleService service, Atomia.Provisioning.Base.ResourceDescription resource)
        {
            this.PrepareCommandList(service, null, resource, ModuleCommandType.Remove);
            this.PrepareAndExecuteCommandsFromList();
        }

        /// <summary>
        /// Rollbacks the transaction.
        /// </summary>
        public override void RollbackTransaction()
        {

            Exception rollback_expection = null;

            int size = this.commands.Count;
            for (int i = size - 1; i >= 0; i--)
            {
                try
                {
                    if (this.commands[i].Status == ModuleCommandStatus.Executed)
                    {
                        this.commands[i].Undo();
                    }

                    this.commands[i].CleanUp();
                }
                catch (Exception e)
                {
                    rollback_expection = e;
                }
            }

            this.commands.Clear();

            if (rollback_expection != null)
            {
                throw rollback_expection;
            }

        }

        #endregion ModuleBase Members
        
        #region IDisposable Members

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        public override void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        private void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    // dispose managed resources
                }

                // dispose unmanaged resources 
                this.disposed = true;
            }
        }

        #endregion IDisposable Members

        /// <summary>
        /// Gets the module command.
        /// </summary>
        /// <param name="resource">The server resource.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="childService">The child service.</param>
        /// <returns>Module command</returns>
        private ModuleCommand GetModuleCommand(ResourceDescription resource, ModuleCommandType commandType, int listDepth, params ModuleService[] childService)
        {

            ModuleCommand command = null;
            Type command_type = typeof(TemplateCommand);
            command = (ModuleCommand)Activator.CreateInstance(command_type, new object[] { childService[0], resource, commandType == ModuleCommandType.Modify ? childService[1] : null, commandType, listDepth, transactionGuid, transactionContext });

            return command;

        }

        /// <summary>
        /// Prepares the command list.
        /// </summary>
        /// <param name="service">Service to populate.</param>
        /// <param name="newServiceSettings">New service settings.</param>
        /// <param name="resource">Server resource.</param>
        /// <param name="commandType">Type of command.</param>
        private void PrepareCommandList(ModuleService service, ModuleService newServiceSettings, ResourceDescription resource, ModuleCommandType commandType)
        {
            if (commandType != ModuleCommandType.Remove)
            {
                this.commands.Add(this.GetModuleCommand(resource, commandType, -1, service, newServiceSettings));
            }

            if (service.Children != null)
            {
                for (int i = 0; i < service.Children.Count; i++)
                {
                    ModuleService childService = service.Children[i];
                    ModuleService newChildSettings = null;
                    if (newServiceSettings != null && newServiceSettings.Children != null && newServiceSettings.Children.Count > i)
                    {
                        newChildSettings = newServiceSettings.Children[i];
                    }

                    this.PrepareCommandList(childService, newChildSettings, resource, commandType);
                }
            }

            if (commandType == ModuleCommandType.Remove)
            {
                this.commands.Add(this.GetModuleCommand(resource, commandType, -1, service, newServiceSettings));
            }
        }

        /// <summary>
        /// Prepares each commands from commands list and execute each commands from the same list. If error occurs during executing one command, Rollback is called.
        /// </summary>
        private void PrepareAndExecuteCommandsFromList()
        {
            foreach (ModuleCommand command in this.commands)
            {
                command.Prepare();
            }

            try
            {
                foreach (ModuleCommand command in this.commands)
                {
                    command.Execute();
                }
            }
            catch
            {
                this.RollbackTransaction();
                throw;
            }
        }

        private string GetServiceDescriptionAssemblyPath()
        {
            return "Atomia.Provisioning.Modules.Template.ServiceDescription.xml";
        }

        public void HandleAndProvide(string[] args)
        {

            if (args == null)
            {
                throw ExceptionHelper.GetModuleException("ID422001", null, null);
            }
            if (args.Length < 3)
            {
                throw ExceptionHelper.GetModuleException("ID422001", null, null);
            }
            
            transactionGuid = new Guid(args[0].ToString().Replace("$", ""));
            transactionContext = args[1].ToString().Replace("$", "");
            string commandType = args[2].ToString();

            switch (commandType)
            {
                case "Add":
                case "Remove":
                    {
                        if (args.Length != 5)
                        {
                            throw ExceptionHelper.GetModuleException("ID422002", null, null);
                        }
                    }
                    break;
                case "Modify":
                    {
                        if (args.Length != 6)
                        {
                            throw ExceptionHelper.GetModuleException("ID422003", null, null);
                        }
                    }
                    break;
                case "RollBackTransaction":
                    {
                    }
                    break;
                case "BeginTransaction":
                    {
                    }
                    break;
                case "CommitTransaction":
                    {
                    }
                    break;
                case "MoveToResource":
                    {
                    }
                    break;
            }

            ModuleService service = new ModuleService("", "");
            ModuleService serviceOld = new ModuleService("", "");
            ModuleService serviceNew = new ModuleService("", "");

            ResourceDescription resource = new ResourceDescription("Template", "ResourceDescriptionFile");

            switch (commandType)
            {
                case "Add":
                case "Remove":
                    {


                        string resourceParamsSerialized = args[3].ToString();
                        string[] paramsSplitted = resourceParamsSerialized.Split(',');

                        for (int i = 0; i < paramsSplitted.Length; i++)
                        {
                            string oneParam = paramsSplitted[i];
                            if (i == 0)
                            {
                                oneParam = oneParam.Substring(1, oneParam.Length - 1); //remove first "{"
                            }
                            if (i == paramsSplitted.Length - 1)
                            {
                                oneParam = oneParam.Substring(0, oneParam.Length - 1); //remove last "}"
                            }
                            string[] oneParamSplitted = oneParam.Split(":".ToArray(), 2, StringSplitOptions.None);
                            string paramName = oneParamSplitted[0].ToString().Replace("\"", "");
                            string paramValue = oneParamSplitted[1].ToString().Replace("\"", "");
                            resource[paramName] = paramValue;
                        }


                        string serviceParamsSerialized = args[4].ToString();
                        paramsSplitted = serviceParamsSerialized.Split(',');

                        for (int i = 0; i < paramsSplitted.Length; i++)
                        {
                            string oneParam = paramsSplitted[i];
                            if (i == 0)
                            {
                                oneParam = oneParam.Substring(1, oneParam.Length - 1); //remove first "{"
                            }
                            if (i == paramsSplitted.Length - 1)
                            {
                                oneParam = oneParam.Substring(0, oneParam.Length - 1); //remove last "}"
                            }
                            
                            string[] oneParamSplitted = oneParam.Split(":".ToArray(), 2, StringSplitOptions.None);
                            string paramName = oneParamSplitted[0].ToString().Replace("\"", "");
                            string paramValue = oneParamSplitted[1].ToString().Replace("\"", "");
                            service.Properties.Add(new ModuleServiceProperty(paramName, paramValue));
                        }

                    }
                    break;

                case "Modify":
                    {

                        string resourceParamsSerialized = args[3].ToString();
                        string[] paramsSplitted = resourceParamsSerialized.Split(',');

                        for (int i = 0; i < paramsSplitted.Length; i++)
                        {
                            string oneParam = paramsSplitted[i];
                            if (i == 0)
                            {
                                oneParam = oneParam.Substring(1, oneParam.Length - 1); //remove first "{"
                            }
                            if (i == paramsSplitted.Length - 1)
                            {
                                oneParam = oneParam.Substring(0, oneParam.Length - 1); //remove last "}"
                            }
                            string[] oneParamSplitted = oneParam.Split(":".ToArray(), 2, StringSplitOptions.None);
                            string paramName = oneParamSplitted[0].ToString().Replace("\"", "");
                            string paramValue = oneParamSplitted[1].ToString().Replace("\"", "");
                            resource[paramName] = paramValue;
                        }

                        string serviceParamsSerialized = args[4].ToString();
                        paramsSplitted = serviceParamsSerialized.Split(',');

                        for (int i = 0; i < paramsSplitted.Length; i++)
                        {
                            string oneParam = paramsSplitted[i];
                            if (i == 0)
                            {
                                oneParam = oneParam.Substring(1, oneParam.Length - 1); //remove first "{"
                            }
                            if (i == paramsSplitted.Length - 1)
                            {
                                oneParam = oneParam.Substring(0, oneParam.Length - 1); //remove last "}"
                            }

                            string[] oneParamSplitted = oneParam.Split(":".ToArray(), 2, StringSplitOptions.None);
                            string paramName = oneParamSplitted[0].ToString().Replace("\"", "");
                            string paramValue = oneParamSplitted[1].ToString().Replace("\"", "");
                            serviceOld.Properties.Add(new ModuleServiceProperty(paramName, paramValue));

                        }


                        serviceParamsSerialized = args[5].ToString();
                        paramsSplitted = serviceParamsSerialized.Split(',');

                        for (int i = 0; i < paramsSplitted.Length; i++)
                        {
                            string oneParam = paramsSplitted[i];
                            if (i == 0)
                            {
                                oneParam = oneParam.Substring(1, oneParam.Length - 1); //remove first "{"
                            }
                            if (i == paramsSplitted.Length - 1)
                            {
                                oneParam = oneParam.Substring(0, oneParam.Length - 1); //remove last "}"
                            }

                            string[] oneParamSplitted = oneParam.Split(":".ToArray(), 2, StringSplitOptions.None);
                            string paramName = oneParamSplitted[0].ToString().Replace("\"", "");
                            string paramValue = oneParamSplitted[1].ToString().Replace("\"", "");
                            serviceNew.Properties.Add(new ModuleServiceProperty(paramName, paramValue));

                        }

                    }
                    break;

            }

            switch (commandType)
            {
                case "Add":
                    {
                        ProvideService(service, resource);
                    }
                    break;
                case "Remove":
                    {
                        RemoveService(service, resource);
                    }
                    break;
                case "Modify":
                    {
                        ModifyService(serviceOld, resource, serviceNew);
                    }
                    break;
            }

        }

        private Dictionary<string, ResourceDescription> GetResourcesForModulePlugin(string moduleName)
        {

            Dictionary<string, ResourceDescription> resources = new Dictionary<string, ResourceDescription>();

            string resourcesFilePath = AppDomain.CurrentDomain.BaseDirectory.Replace("Modules\\", "");
            resourcesFilePath = resourcesFilePath + "resources.xml";

            System.Xml.Linq.XDocument xmlDoc = null;

            try
            {
                xmlDoc = System.Xml.Linq.XDocument.Load(resourcesFilePath);
            }
            catch (Exception ex)
            {
                throw ExceptionHelper.GetModuleException("ID422004", null, ex);
            }

            if (xmlDoc == null)
            {
            }
            else
            {
                foreach (System.Xml.Linq.XElement resourceAndPolicy in xmlDoc.Root.Elements("bindings"))
                {
                    resources = FillBindingsElement(resourceAndPolicy, moduleName);
                }
            }

            return resources;

        }

        /// <summary>
        /// Fill resource and policy elements
        /// </summary>
        /// <param name="resourceAndPolicy">The resource and policy.</param>
        protected Dictionary<string, ResourceDescription> FillBindingsElement(System.Xml.Linq.XElement resourceAndPolicy, string moduleName)
        {

            Dictionary<string, ResourceDescription> resources = new Dictionary<string, ResourceDescription>();

            // find all resources descriptions for module
            foreach (System.Xml.Linq.XElement module in resourceAndPolicy.Element("moduleList").Elements())
            {
                if (module.Attribute("name").Value == moduleName)
                {

                    foreach (System.Xml.Linq.XElement resourceItem in resourceAndPolicy.Element("resourceList").Elements())
                    {

                        ResourceDescription resourceDesc = new ResourceDescription(resourceItem.Attribute("name").Value, moduleName);

                        resourceDesc.ShouldBeLocked = true;

                        foreach (System.Xml.Linq.XElement propElem in resourceItem.Elements("property"))
                        {
                            resourceDesc[propElem.Attribute("name").Value] = propElem.Value;
                        }

                        foreach (System.Xml.Linq.XElement propListEl in resourceItem.Elements("propertyList"))
                        {
                            ResourceDescriptionPropertyList resDescPropList = new ResourceDescriptionPropertyList();
                            resDescPropList.PropertyListName = propListEl.Attribute("name").Value;
                            foreach (System.Xml.Linq.XElement propListItem in propListEl.Elements("propertyListItem"))
                            {
                                resDescPropList.PropertyListItems.Add(propListItem.Value);
                            }

                            resourceDesc.PropertyList.Add(resDescPropList);
                        }

                        // first check if this resource already exist in list of resoources
                        if (resources.ContainsKey(resourceDesc.Name))
                        {
                            // check if they are the same
                            if (resourceDesc.Equals(resources[resourceDesc.Name]))
                            {
                                resourceDesc = resources[resourceDesc.Name];
                            }
                            else
                            {
                                // they have the same name but settings are different.
                                // this is not allowed
                                throw ExceptionHelper.GetModuleException("ID422005", new Dictionary<string, string>() { { "Message", resourceDesc.Name } }, null);
                            }
                        }
                        else
                        {
                            resources[resourceDesc.Name] = resourceDesc;
                        }

                    }

                }
            }

            return resources;

        }

    }
}
