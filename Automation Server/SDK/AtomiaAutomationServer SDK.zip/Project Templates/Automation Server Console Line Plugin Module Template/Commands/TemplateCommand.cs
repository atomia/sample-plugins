﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atomia.Provisioning.Modules.Common;
using Atomia.Provisioning.Base;
using Atomia.Provisioning.Base.Module;
using System.IO;

namespace Atomia.Provisioning.Modules.Template.Commands
{
    public class TemplateCommand : ModuleCommandSimpleBase
    {

        private string transContext = string.Empty;
        private Guid transGuid = Guid.Empty;

        public TemplateCommand(ModuleService service, ResourceDescription resource, ModuleService newServiceSettings, ModuleCommandType commandType, int listDepth, Guid transGUID, string transContext)
            : base(service, resource, newServiceSettings, commandType, listDepth)
        {
            this.transContext = transContext;
            this.transGuid = transGUID;
        }

        protected override void ExecuteModify(ModuleService oldService, ModuleService newService)
        {

            switch (transContext)
            {
                case "BeginTransaction":
                    {
                        
                    }
                    break;
                case "CommitTransaction":
                    {
                        
                    }
                    break;
                case "RollBackTransaction":
                    {
                        
                    }
                    break;
            }
            
            
        }

        protected override void ExecuteAdd(Base.Module.ModuleService moduleService)
        {

            switch(transContext)
            {
                case "BeginTransaction":
                    {
                        
                    }
                    break;
                case "CommitTransaction":
                    {
                        
                    }
                    break;
                case "RollBackTransaction":
                    {
                        
                    }
                    break;
            }

            

        }

        protected override void ExecuteRemove(Base.Module.ModuleService moduleService)
        {
            
            switch (transContext)
            {
                case "BeginTransaction":
                    {
                        
                    }
                    break;
                case "CommitTransaction":
                    {
                        
                    }
                    break;
                case "RollBackTransaction":
                    {
                        
                    }
                    break;
            }
            

        }

        protected override void ValidateService(Base.Module.ModuleService moduleService)
        {
            
        }

        public override string CallOperation(string operationName, string operationArgument)
        {
            return string.Empty;
        }



    }
}
