﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Atomia.Provisioning.Modules.Template
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Template f = new Template();
                f.HandleAndProvide(args);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw ex;
            }
        }
    }
}
